package com.example

import com.google.auth.oauth2.GoogleCredentials
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation as ClientContentNegotiation
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation as ServerContentNegotiation
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*

@Serializable
data class ChatRequest(
    val message: String,
    val image: ChatImage? = null,
    val conversationId: String? = null
)

@Serializable
data class ChatImage(
    val mimeType: String,
    val base64Data: String
)

@Serializable
data class ChatResponse(
    val answer: String,
    val conversationId: String? = null
)

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080

    val projectId = System.getenv("GOOGLE_CLOUD_PROJECT")
        ?: error("GOOGLE_CLOUD_PROJECT env var is missing")

    val location = System.getenv("VERTEX_AI_LOCATION") ?: "us-central1"
    val model = System.getenv("GEMINI_MODEL") ?: "gemini-2.5-flash-lite"

    val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = false
    }

    val httpClient = HttpClient(CIO) {
        install(ClientContentNegotiation) {
            json(json)
        }
    }

    embeddedServer(Netty, port = port) {
        install(ServerContentNegotiation) {
            json(json)
        }

        routing {
            get("/") {
                call.respondText("Smart Image Chat API is running with Gemini")
            }

            post("/chat") {
                val request = call.receive<ChatRequest>()

                if (request.message.isBlank()) {
                    call.respond(
                        HttpStatusCode.BadRequest,
                        ChatResponse(
                            answer = "Message cannot be empty.",
                            conversationId = request.conversationId
                        )
                    )
                    return@post
                }

                val answer = callGemini(
                    httpClient = httpClient,
                    projectId = projectId,
                    location = location,
                    model = model,
                    userMessage = request.message,
                    image = request.image
                )

                call.respond(
                    ChatResponse(
                        answer = answer,
                        conversationId = request.conversationId
                    )
                )
            }
        }
    }.start(wait = true)
}

suspend fun callGemini(
    httpClient: HttpClient,
    projectId: String,
    location: String,
    model: String,
    userMessage: String,
    image: ChatImage?
): String {
    val credentials = GoogleCredentials
        .getApplicationDefault()
        .createScoped(listOf("https://www.googleapis.com/auth/cloud-platform"))

    credentials.refreshIfExpired()

    val accessToken = credentials.accessToken.tokenValue

    val endpoint =
        "https://$location-aiplatform.googleapis.com/v1/projects/$projectId/locations/$location/publishers/google/models/$model:generateContent"

    val systemInstruction = """
        You are an AI assistant inside an Android smart image application.

        The app uses local machine learning models to classify objects, plants, aircraft, and visual patterns.

        Your job:
        - Explain the detected result clearly.
        - Mention uncertainty when confidence is low.
        - Avoid pretending the local model is always correct.
        - Keep the answer concise and useful.
        - Use simple language for mobile users.
    """.trimIndent()

    val body = buildJsonObject {
        putJsonObject("systemInstruction") {
            putJsonArray("parts") {
                addJsonObject {
                    put("text", systemInstruction)
                }
            }
        }

        putJsonArray("contents") {
            addJsonObject {
                put("role", "user")
                putJsonArray("parts") {
                    addJsonObject {
                        put("text", userMessage)
                    }

                    image?.let {
                        addJsonObject {
                            putJsonObject("inlineData") {
                                put("mimeType", it.mimeType)
                                put("data", it.base64Data)
                            }
                        }
                    }
                }
            }
        }

        putJsonObject("generationConfig") {
            put("temperature", 0.4)
            put("maxOutputTokens", 256)
        }
    }

    val responseText = httpClient.post(endpoint) {
        header(HttpHeaders.Authorization, "Bearer $accessToken")
        contentType(ContentType.Application.Json)
        setBody(body)
    }.body<String>()

    val responseJson = Json.parseToJsonElement(responseText).jsonObject

    return responseJson["candidates"]
        ?.jsonArray
        ?.firstOrNull()
        ?.jsonObject
        ?.get("content")
        ?.jsonObject
        ?.get("parts")
        ?.jsonArray
        ?.firstOrNull()
        ?.jsonObject
        ?.get("text")
        ?.jsonPrimitive
        ?.contentOrNull
        ?: "I could not generate a response."
}
